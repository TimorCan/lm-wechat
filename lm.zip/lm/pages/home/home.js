// pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    totalPeople:"100",
    normalPeople:"20",
    latePeople:"80",
    year: new Date().getFullYear(),      // 年份
    month: new Date().getMonth() + 1,    // 月份
    day: new Date().getDate(),            //日

    calendar_days_style: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.calendarInit();
  },

  /**
   * 跳转正常考勤人员列表
   */
  clicknormalList(){

    wx.navigateTo({
      url: '../normalList/normalList'
    })

  },

  /**
   * 日历的一些初始化设置
   */
  calendarInit(){

    var that = this;
    
    let calendar_days_style = new Array;

    const days_count = new Date(this.data.year, this.data.month, 0).getDate();
    for (let i = 1; i <= days_count; i++) {
        const date = new Date(this.data.year, this.data.month - 1, i);
        if (i == that.data.day) {
            calendar_days_style.push({
                month: 'current', day: i, color: 'white', background: '#ff6d6d'
            });
        }  else {
            calendar_days_style.push({
                month: 'current', day: i, color: 'black'
            });
        }
    }

    this.setData({
        calendar_days_style
    });
  },
  
  //给点击的日期设置一个背景颜色
  dayClick: function (event) {
    var that = this;

    let calendar_days_style = new Array;

    const days_count = new Date(this.data.year, this.data.month, 0).getDate();
    for (let i = 1; i <= days_count; i++) {
        if (i == that.data.day) {
            calendar_days_style.push({
                month: 'current', day: i, color: 'white', background: '#ff6d6d'
            });
        }else if(i == event.detail.day){
          calendar_days_style.push({
            month: 'current', day: i, color: 'white', background: '#55c795'
        });
        }else {
            calendar_days_style.push({
                month: 'current', day: i, color: 'black'
            });
        }
      }
        this.setData({
          calendar_days_style
      });
    

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
    const context = wx.createCanvasContext('canvas-1')
    let progressCircleCorlor = "#55c795";
    this.drawHomePageCircle(context,progressCircleCorlor,"正常",0.9);

    const context2 = wx.createCanvasContext('canvas-2')
    let progressCircleCorlor2 = "#f5c25f";
    this.drawHomePageCircle(context2,progressCircleCorlor2,"迟到",0.4);
    
  },
  drawHomePageCircle(context,progressCircleCorlor,normalText,percent){
    let lineWidth = 8;
    let backCicleCorlor = "#f6f6f6";
    let cap = "round";
    let xy = 60
    let r = 40



    context.save();
    context.beginPath();
    context.setLineWidth(lineWidth) //设置线宽
    context.setStrokeStyle(backCicleCorlor);
    context.arc(xy, xy, r, 0, Math.PI * 2, false);
    context.stroke();

    // context.draw()
    context.closePath();
    context.restore();

    context.save();
    context.setLineWidth(lineWidth) //设置线宽
    context.setStrokeStyle(progressCircleCorlor);
    context.setLineCap(cap);
    context.beginPath(); //路径开始
    context.arc(xy, xy, r, -Math.PI / 2, (Math.PI * 2 * percent) - Math.PI/2, false);
    context.stroke(); //绘制
    context.closePath(); //路径结束
    // context.draw() //最后写这个
    context.restore();
    


    context.save();
    context.beginPath();
    context.setFillStyle(progressCircleCorlor)
    context.setFontSize(15)
    context.setTextAlign('center');
    context.fillText(normalText, xy, xy-8);
    context.stroke(); //绘制
    context.closePath(); //路径结束
    // context.draw()
    context.restore();

    const percentStr = parseInt(percent * 100)  + "%";

    context.save();
    context.beginPath();
    context.setFillStyle(progressCircleCorlor)
    context.setFontSize(18)
    context.setTextAlign('center');
    context.fillText(percentStr, xy, xy+15);
    context.stroke(); //绘制
    context.closePath(); //路径结束
    context.draw()
    context.restore();

    //绘制内部数据
    //1.正常 or 迟到
    //2.绘制 内部百分比进度 5%


  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  showToast() {
    let $toast = this.selectComponent(".J_toast")
    $toast && $toast.show()
  }
})