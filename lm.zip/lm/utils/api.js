
// api 统一封装

const host = '???'

const config = {

  // host
  host,

  // 登录
  loginUrl: `http://${host}/basics/sysAuth/loginIn`,


}

module.exports = config
