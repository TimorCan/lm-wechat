//app.js

import util from "./utils/request.js";
import api from "./utils/api.js";

const lm_header = {}



App({

  onGetItemList: function(){

    let data = {
      "userPhone":"122",
      "passWord":"123333456"
    }
    wx.cloud.callFunction({
        name: 'proxy',
        data: {
            // http域名 https域名 第三方域名 非验证域名 IP[:prot] 内网IP或花生壳域名
            uri: api.host,
            headers: lm_header,
            body: data
        }
    }).then(res => {
        console.log(res)
        const data = res.result
        console.log(data)
        // do something
    })
},
  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    

    // wx.cloud.init();
    // this.onGetItemList();







    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  },
  globalData: {
    userInfo: null
  }
})